pip install numpy
pip install pandas
pip install sklearn
pip install matplotlib